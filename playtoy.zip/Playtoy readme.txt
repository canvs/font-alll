TrueTypeFont: Playtoy
Dennis Ludlow Productions 2000 all rights reserved
Sharkshock Productions

Hi everybody. This font goes out to all the guys (and yes even
girls) that didnt think twice before skimming through a playboy
magazine in front of their friends. There are a few tricks with 
this font you should know. First, the capital "O" will spell out 
the O with the bunny logo centered in it. The @ features the bunny
as well. All lowercase letters will spell out the bunny. The lower-
case "p" is special as well. Hope you enjoy!

check out my graphic archive at www.sharkshock.uni.cc
                                  "Take a bite out of BORING design!"