TrueTypeFont: Subway
Dennis Ludlow Productions 2000 all rights reserved
Sharkshock Productions

Hi everybody. This font might make you hungry just reading it. As with most of my other
typefaces, there are a of couple tricks to this one. A circular enclosure can be automatically
made by the parenthesees. It will house the word Subway, and others that are of similar size
perfectly. An outlined "WAY" can be spelled by most of the various keys not usually used like 
the amperstand and asterisk. As with all my fonts, this one is free for distribution
and non-commercial use.Hope you enjoy!

check out my graphic archive at www.sharkshock.uni.cc
                                  "Take a bite out of BORING design!"