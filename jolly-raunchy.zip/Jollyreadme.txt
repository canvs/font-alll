TrueTypeFont: Jolly Raunchy
Dennis Ludlow Productions 2000 all rights reserved
Sharkshock Productions

Hey there everyone. Hope your mouth waters using this font inspired by the yummy
candies that would eliminate bad breath at the drop of a dime. Free for non-commercial use
of any kind. This font is intended to be an exclusive to www.1001freefonts.com as well as my 
site as well. Enjoy!

check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"