TrueTypeFont: Mr.Goodbaur
Dennis Ludlow Productions 2000 all rights reserved
Sharkshock Productions

Hey everyone. I got the idea for this font when  i realized i left the candy bar i just bought in
my girlfriend's car. Like you care.... anyway, a few special things are the amperstand and @ 
symbol which are both spelled out small. Hope you enjoy. Feel free to distribute this font on 
your site for non-commercial use.
check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"