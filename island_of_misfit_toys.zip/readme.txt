All official material on "Rudolph the Red Nosed Reindeer�" is copyright by Rankin and Bass, and Trademarks Classic Media, Inc. 
This is fan-produced material intended to promote interest in the TV Specials of Rankin/Bass. I include the GE� logo since at the time General Electric was a sponsor of Rudolph the Red Nosed Reindeer�
The materials are provided as FREEWARE for your enjoyment, 
but should not be used for any commercial purpose. (This Read must be include with this font.)

Introduction
~~~~~~~~~~~~
Thank you for downloading my "Island of Misfit Toys" Fonts TTF for Windows, I hope you enjoy using it. 
This set includes 2 fonts the Reg offset and the Alt. inline font.

Requirements
~~~~~~~~~~~~
Windows 98,2000,Me�,XP�

Install
~~~~~~~
1. UnZip, install into C:\windows\fonts.

Uninstall
~~~~~~~~~
Delete the Startup\Settings\Control Panel\Fonts\(highlight font to be deleted)File\Delete.

Created By
~~~~~~~~~~
Date:7/22/2006 updated 6/27/09, 12/04/10

Filename: Island of Misfit Toys.zip 
Title: Island of Misfit
Category: TV : Rudolph the Red Nosed Reindeer�
Archive: Fonts

Island of Misfit Toys Dingbats and Other Fonts are available.

Suggestions or comments sent to Steve Ferrera : supercarguy@hotmail.com
ENJOY!!!






RuFus


